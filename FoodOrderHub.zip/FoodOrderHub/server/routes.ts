import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertMenuItemSchema, insertOrderSchema } from "@shared/schema";
import { createPaymentIntent } from "./stripe";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  app.get("/api/menu", async (req, res) => {
    const items = await storage.getMenuItems();
    res.json(items);
  });

  app.post("/api/menu", async (req, res) => {
    if (!req.user?.isAdmin) {
      return res.status(403).send("Unauthorized");
    }
    
    const parsed = insertMenuItemSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json(parsed.error);
    }
    
    const item = await storage.createMenuItem(parsed.data);
    res.status(201).json(item);
  });

  app.patch("/api/menu/:id", async (req, res) => {
    if (!req.user?.isAdmin) {
      return res.status(403).send("Unauthorized");
    }
    
    const id = parseInt(req.params.id);
    const item = await storage.updateMenuItem(id, req.body);
    res.json(item);
  });

  app.delete("/api/menu/:id", async (req, res) => {
    if (!req.user?.isAdmin) {
      return res.status(403).send("Unauthorized");
    }
    
    const id = parseInt(req.params.id);
    await storage.deleteMenuItem(id);
    res.sendStatus(200);
  });

  app.get("/api/orders", async (req, res) => {
    if (req.user?.isAdmin) {
      const orders = await storage.getOrders();
      res.json(orders);
    } else {
      const orders = await storage.getUserOrders(req.user!.id);
      res.json(orders);
    }
  });

  app.post("/api/orders", async (req, res) => {
    if (!req.user) {
      return res.status(401).send("Unauthorized");
    }
    
    const parsed = insertOrderSchema.safeParse({
      ...req.body,
      userId: req.user.id,
    });
    if (!parsed.success) {
      return res.status(400).json(parsed.error);
    }
    
    const order = await storage.createOrder(parsed.data);
    res.status(201).json(order);
  });

  app.patch("/api/orders/:id/status", async (req, res) => {
    if (!req.user?.isAdmin) {
      return res.status(403).send("Unauthorized");
    }
    
    const id = parseInt(req.params.id);
    const order = await storage.updateOrderStatus(id, req.body.status);
    res.json(order);
  });

  app.post("/api/create-payment-intent", async (req, res) => {
    if (!req.user) {
      return res.status(401).send("Unauthorized");
    }

    const order = await storage.getOrder(req.body.orderId);
    if (!order) {
      return res.status(404).send("Order not found");
    }

    const paymentIntent = await createPaymentIntent(order);
    res.json({ clientSecret: paymentIntent.client_secret });
  });

  const httpServer = createServer(app);
  return httpServer;
}
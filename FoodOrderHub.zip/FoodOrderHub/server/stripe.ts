import Stripe from "stripe";
import { Order } from "@shared/schema";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error("STRIPE_SECRET_KEY is required");
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-01-27.acacia",
});

export async function createPaymentIntent(order: Order) {
  // Ensure minimum charge amount (50 cents for USD)
  const amount = Math.max(order.total, 50);

  const paymentIntent = await stripe.paymentIntents.create({
    amount,
    currency: "usd",
    metadata: {
      orderId: order.id.toString(),
    },
  });

  return paymentIntent;
}
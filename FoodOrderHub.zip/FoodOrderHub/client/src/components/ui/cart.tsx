import { Button } from "./button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "./sheet";
import { ScrollArea } from "./scroll-area";
import { ShoppingCart, Minus, Plus, Trash2 } from "lucide-react";
import { useCart } from "@/hooks/use-cart";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "./badge";
import { Elements } from "@stripe/react-stripe-js";
import { getStripe } from "@/lib/stripe";
import { PaymentForm } from "./payment-form";

export function Cart() {
  const [open, setOpen] = useState(false);
  const { items, total, updateQuantity, removeFromCart, clearCart } = useCart();
  const { toast } = useToast();

  const checkoutMutation = useMutation({
    mutationFn: async () => {
      const orderRes = await apiRequest("POST", "/api/orders", {
        total,
        status: "pending",
        items: items.map((item) => ({
          id: item.id,
          quantity: item.quantity,
        })),
      });
      const order = await orderRes.json();

      const paymentRes = await apiRequest("POST", "/api/create-payment-intent", {
        orderId: order.id,
      });
      const { clientSecret } = await paymentRes.json();

      return { order, clientSecret };
    },
    onSuccess: () => {
      clearCart();
      setOpen(false);
      toast({
        title: "Order placed successfully",
        description: "Thank you for your order!",
      });
    },
  });

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="outline" size="icon" className="relative">
          <ShoppingCart className="h-4 w-4" />
          {items.length > 0 && (
            <Badge
              variant="destructive"
              className="absolute -top-2 -right-2 h-5 w-5 p-0 flex items-center justify-center"
            >
              {items.length}
            </Badge>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent>
        <SheetHeader>
          <SheetTitle>Your Cart</SheetTitle>
        </SheetHeader>

        <ScrollArea className="h-[calc(100vh-200px)] mt-4">
          {items.length === 0 ? (
            <p className="text-center text-muted-foreground pt-4">
              Your cart is empty
            </p>
          ) : (
            <div className="space-y-4">
              {items.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between gap-4 border-b pb-4"
                >
                  <div className="flex-1">
                    <h3 className="font-medium">{item.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      ${(item.price / 100).toFixed(2)}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                    <span className="w-8 text-center">{item.quantity}</span>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="destructive"
                      size="icon"
                      onClick={() => removeFromCart(item.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>

        {items.length > 0 && (
          <div className="mt-4 space-y-4">
            <div className="flex justify-between font-medium">
              <span>Total</span>
              <span>${(total / 100).toFixed(2)}</span>
            </div>
            {checkoutMutation.data?.clientSecret ? (
              <Elements
                stripe={getStripe()}
                options={{ clientSecret: checkoutMutation.data.clientSecret }}
              >
                <PaymentForm clientSecret={checkoutMutation.data.clientSecret} />
              </Elements>
            ) : (
              <Button
                className="w-full"
                onClick={() => checkoutMutation.mutate()}
                disabled={checkoutMutation.isPending}
              >
                {checkoutMutation.isPending ? "Processing..." : "Proceed to Payment"}
              </Button>
            )}
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}
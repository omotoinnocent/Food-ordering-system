import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useStripe } from "@stripe/react-stripe-js";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/use-cart";

export default function OrderConfirmationPage() {
  const stripe = useStripe();
  const [, setLocation] = useLocation();
  const { clearCart } = useCart();
  const [status, setStatus] = useState<"success" | "failed">();

  useEffect(() => {
    if (!stripe) {
      return;
    }

    // Retrieve the "payment_intent_client_secret" query parameter
    const clientSecret = new URLSearchParams(window.location.search).get(
      "payment_intent_client_secret"
    );

    if (clientSecret) {
      stripe
        .retrievePaymentIntent(clientSecret)
        .then(({ paymentIntent }) => {
          switch (paymentIntent?.status) {
            case "succeeded":
              setStatus("success");
              clearCart();
              break;
            default:
              setStatus("failed");
              break;
          }
        });
    }
  }, [stripe]);

  if (!status) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {status === "success" ? (
              <>
                <CheckCircle2 className="h-6 w-6 text-green-500" />
                Order Confirmed
              </>
            ) : (
              <>
                <XCircle className="h-6 w-6 text-destructive" />
                Payment Failed
              </>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-muted-foreground">
            {status === "success"
              ? "Thank you for your order! We'll start preparing it right away."
              : "There was a problem processing your payment. Please try again."}
          </p>
          <Button className="w-full" onClick={() => setLocation("/")}>
            Return to Home
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}